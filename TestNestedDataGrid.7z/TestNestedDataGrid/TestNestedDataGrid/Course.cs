﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestNestedDataGrid
{
    public class Course
    {
        public string CourseName { get; set; }
        public string Teacher { get; set; }
        public int Score { get; set; }
        public string ClassRoom { get; set; }
    }
}
