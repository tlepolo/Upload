﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace TestNestedDataGrid
{
    public class RelayCommand : ICommand
    {
        public event EventHandler CanExecuteChanged;
        public Action<object> DoExecute { get; set; }
        public Func<object, bool> DoCanExecute { get; set; }

        public bool CanExecute(object parameter)
        {
            if (DoCanExecute == null)
            {
                return true;
            }
            return DoCanExecute(parameter);
        }

        public void Execute(object parameter)
        {
            DoExecute?.Invoke(parameter);
        }

        public RelayCommand(Action<object> doExecute, Func<object, bool> doCanExecute = null)
        {
            DoExecute = doExecute;
            DoCanExecute = doCanExecute;
        }
    }
}
