﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace TestNestedDataGrid
{
    public class MainViewModel : ViewModelBase
    {
        private int detailIndex;
        private ObservableCollection<Student> students;
        public RelayCommand BtnCommnand { get; set; }
        public RelayCommand DetailCommand { get; set; }

        public int DetailIndex
        {
            get { return detailIndex; }
            set
            {
                detailIndex = value;
                RaisePropertyChanged();
            }
        }


        public ObservableCollection<Student> Students
        {
            get => students; set
            {
                students = value;
                RaisePropertyChanged();
            }
        }

        public MainViewModel()
        {
            Students = new ObservableCollection<Student>();
            for (int i = 1; i < 20; i++)
            {
                Student student = new Student();
                student.Id = i;
                student.Age = 10 + i;
                student.Major = "EE" + i;
                student.Name = "zmj" + i;
                student.ImagePath = "/avatar" + "/" + i.ToString("00") + ".png";
                student.Courses = new List<Course> { new Course { CourseName = "Java", ClassRoom = "i", Score = 90 + i, Teacher = "teacher" + i } };
                Students.Add(student);
            }
            BtnCommnand = new RelayCommand(obj =>
            {

            });
            DetailCommand = new RelayCommand(obj =>
            {
                DataGridRow dataGridRow = (DataGridRow)(obj as DataGrid).ItemContainerGenerator.ContainerFromIndex(DetailIndex);
                if (dataGridRow.DetailsVisibility==Visibility.Visible)
                {
                    dataGridRow.DetailsVisibility = Visibility.Collapsed;
                }
                else
                {
                    dataGridRow.DetailsVisibility = Visibility.Visible;
                }

            });
         
        }

    }
}
